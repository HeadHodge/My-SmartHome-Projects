import imports.options as options
print('Load disconnectEndpoint')

_bucket = options.service['dataBucket']
_key = None

def start(client, connectionId, event, context):
    print(f'Start disconnectEndpoint')
    
    _key = options.service['indexPath']['connections'].replace('$connection', connectionId)
    client.delete_object(
        Bucket = _bucket,
        Key    = _key,
    )
        
    print(f'disconnectEndpoint completed')

    return {
        'statusCode': 200,
        'body': json.dumps({
            'state' : 1,
            'lambda': f'disconnectEndpoint',
            'status': f'endpoint disconnected',
        }),
    }
