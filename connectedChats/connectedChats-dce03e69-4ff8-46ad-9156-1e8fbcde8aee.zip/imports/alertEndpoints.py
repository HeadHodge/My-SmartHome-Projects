import json, traceback, boto3
import imports.options as options
print('Loading alertEndpoints')

_bucket = options.service['dataBucket']
_key = None

def start(client, payload, event, context):
    print(f'Start alertEndpoints')
    
    _prefix = options.service['indexPath']['categoryTopics'].replace('$category', 'random thoughts').replace('$topic', payload['uts'])
    list = client.list_objects_v2(
        Bucket = _bucket,
        Prefix = _prefix
    )
    
    _path = list['Contents'][0]['Key'].split('/')
    _key  = options.service['entityPath']['topics'].replace('$topic', _path[len(_path)-2])
    print(_path, _key)
    object = client.get_object(
        Bucket= _bucket,
        Key   = _key
    )

    post = json.loads(object['Body'].read())
    print(f"uts: {post['uts']},  post: {post['topic']}")
    
    _prefix = 'indexes/connections/'    
    list = client.list_objects_v2(
        Bucket = _bucket,
        Prefix = _prefix
    )
    
    try:
        _path = list['Contents'][0]['Key'].split('/')
        _connectionId = _path[len(_path)-2]    
        _gatewayapi = boto3.client("apigatewaymanagementapi", endpoint_url = options.service['endpointUrl'])
        _gatewayapi.post_to_connection(
            ConnectionId = _connectionId,
            Data = post["topic"]
        )
    except:
        _key = options.service['indexPath']['connections'].replace('$connection', _connectionId)
        client.delete_object(
            Bucket = _bucket,
            Key    = _key,
        )
            
    print(f'alertEndpoints completed')
