twocentChats = {
    'endpointUrl': 'https://jzqy8hjd1g.execute-api.us-west-1.amazonaws.com/development',
    'htmlBucket' : 'twocentchats.com',
    'dataBucket' : 'www.connectedchats.com',
    'entityPath' : {
        'categories': 'entities/categories/$category.category',
        'topics'    : 'entities/topics/$topic.topic',
    },    
    'indexPath'  : {
        'connections'   : 'indexes/connections/$connection/',
        'categoryTopics': 'indexes/categories/$category/topics/$topic/',
    },
}

service = twocentChats
