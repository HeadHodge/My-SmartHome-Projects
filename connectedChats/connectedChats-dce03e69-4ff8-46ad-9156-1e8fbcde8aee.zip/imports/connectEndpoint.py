import imports.options as options
print('Load connectEndpoint')

_bucket = options.service['dataBucket']
_key = None

def start(client, connectionId, event, context):
    print(f'Start connectEndpoint')
    
    _key = options.service['indexPath']['connections'].replace('$connection', connectionId)
    client.put_object(
        Bucket = _bucket,
        Key = _key,
    )

    print(f'connectEndpoint completed')

    return {
        'statusCode': 200,
        'body': json.dumps({
            'state' : 1,
            'lambda': f'connectEndpoint',
            'status': f'endpoint connected',
        }),
    }
