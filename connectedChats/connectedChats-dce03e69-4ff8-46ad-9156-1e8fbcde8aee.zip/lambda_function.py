import json, importlib, traceback, boto3
import imports.options as options

print(f'Load connectedChats')

validActions = {
    'addTopic' : 'addTopic',
}

def lambda_handler(event, context):
    try:
        print(f'Start connectedChats')
        
        client = boto3.client('s3')
        clientIp = event['requestContext']['identity']['sourceIp']
        connectionId = event['requestContext']['connectionId']
        routeKey = event['requestContext']['routeKey']
        print(f'**connectedChats** routeKey: {routeKey}, clientIp: {clientIp}, connectionId: {connectionId}')
        
        if(routeKey == '$connect'):
            object = importlib.import_module('imports.connectEndpoint')
            return object.start(client, connectionId, event, context)  
         
        if(routeKey == '$disconnect'):
            object = importlib.import_module('imports.disconnectEndpoint')
            return object.start(client, connectionId, event, context)  
           
        payload = json.loads(event['body'])        
        action = payload['action']
        module = validActions.get(action, None)
        if(module == None): raise Exception(f'Abort connectedChats: Invalid Action: {action}')
      
        object = importlib.import_module(module)
        return object.start(client, payload, event, context)  
    except:
        return {
            'statusCode': 200,
            'body': json.dumps({
                'state' : 0,
                'lambda': f'connectedChats',
                'status': f'^^Abort connectedChats: {traceback.format_exc()}',
            }),
        }
