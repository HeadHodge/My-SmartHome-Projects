import json, traceback, boto3
import imports.options as options
import imports.alertEndpoints as alertEndpoints
print('Loading addTopic')

_bucket = options.service['dataBucket']
_key = None

def start(client, payload, event, context):
    try:
        print(f'Start addTopic')

        _key  = options.service['entityPath']['categories'].replace('$category', payload['category'])
        _body = json.dumps({'category': payload['category'], 'uts': payload['uts']})
        client.put_object(
            Bucket= _bucket,
            Key   = _key,
            Body  = _body
        )
     
        _key  = options.service['entityPath']['topics'].replace('$topic', payload['uts'])
        _body = json.dumps(payload)
        client.put_object(
            Bucket = _bucket,
            Key    = _key,
            Body   = _body
        )
    
        _key  = options.service['indexPath']['categoryTopics'].replace('$category', payload['category']).replace('$topic', payload['uts'])
        client.put_object(
            Bucket = _bucket,
            Key    = _key
        )
    
        alertEndpoints.start(client, payload, event, context)

        print(f'addTopic completed')
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'state' : 1,
                'lambda': 'addTopic',
                'status': 'New topic added',
            }),
        }
    except:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'state' : 0,
                'lambda': f'addTopic',
                'status': f'**Abort addTopic: {traceback.format_exc()}',
            }),
        }
