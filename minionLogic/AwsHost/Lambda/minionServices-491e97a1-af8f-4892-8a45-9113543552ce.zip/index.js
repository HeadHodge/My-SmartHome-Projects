var fs = require("fs");

var AWS = require('aws-sdk'); AWS.config.update({region: 'us-west-2'});

var apiGateway = new AWS.ApiGatewayManagementApi({
    endpoint: 'https://8lcl01nzg5.execute-api.us-west-2.amazonaws.com/production/',
});

var S3 = new AWS.S3({});

var receivedOrder = {};

///////////////////////////////////////////////////////////////////
global.saveContract = async function(key, contract) {
console.log(`saveContract: `, key, contract);

//createContract
    var params = {
        Bucket: 'minionlogic',
        Key   : 'contracts/' + key,
        Body  : JSON.stringify(contract),
        ContentType: 'text/plain',
    };
        
	//console.log(`createContract, put objectKey: `, params);
  await S3.putObject(params).promise();
};

/////////////////////////////////////////
global.sendUpdate = async function(contactType, orderUpdate) {
///////////////////////////////////////  
console.log(`***Enter sendUpdate to: '${contactType}'`);

//Get contact connection
  var contactName = orderUpdate.TICKET[contactType];
  
  var params = {
    Bucket: 'minionlogic',
    Key   : 'connections/nameList/' + contactName,
  };
  
  console.log(`getConnection, params: `, params);
  var objectBuffer=await S3.getObject(params).promise();
  var connection = JSON.parse(objectBuffer.Body.toString('utf-8')).connection;

//var connection = receivedMemo.requestContext.connectionId;

  params = {
    ConnectionId: connection,
    Data        : JSON.stringify(orderUpdate),
  };

  console.log('\n***memo params: ', params);
  await apiGateway.postToConnection(params).promise();
};

//////////////////////////////////////////////////////////
global.loadObject = async function(objectKey) {
//////////////////////////////////////////////////////////
console.log(`***loadObject: ${objectKey}`);
var objectBuffer;

//getObject
    var params = {
        Bucket: 'minionlogic',
        Key   : objectKey,
    };
  
  console.log(`getObject, params: : `, params);
  objectBuffer = await S3.getObject(params).promise();
  console.log(`objectBuffer: `, objectBuffer.Body.toString('utf-8'));
  return JSON.parse(objectBuffer.Body.toString('utf-8')); 
};

//////////////////////////////////////////////////////////
global.loadModule = async function(path, module) {
//////////////////////////////////////////////////////////
console.log(`***loadModule: ${path}, ${module}`);
var objectBuffer, objectKey = path + module, tmpDir = '/tmp/'+ path, tmpFile = '/tmp/'+ path + module;
  
  //console.log(`get objectKey: ${objectKey}`);
  objectBuffer=await S3.getObject({Bucket: 'minionlogic', Key: objectKey}).promise();

  //console.log(`create dir: ${tmpDir}`);
  if (!fs.existsSync(tmpDir)){
    fs.mkdirSync(tmpDir, { recursive: true });
  }
  
  //console.log(`create file: ${tmpFile}`);
  fs.writeFileSync(tmpFile, objectBuffer.Body.toString('utf-8'));
  
  console.log(`load file: ${tmpFile}`);
  return require(tmpFile); 
};

///////////////////////////////////////////////
/////////////////  MAIN    ////////////////////
///////////////////////////////////////////////
exports.handler = async (memo) => {
console.log(`*** Start minionServices`, memo);

try {
  //////////////////////////////////////////////
  ////////NOTE: REMOVE REMOVE REQIRE CACHE//////
  ///////////////WHEN NOT TESTING///////////////
  //////////////////////////////////////////////
/*
  if(memo["queryStringParameters"].trialMode == 'on') {
    console.log(`***trialMode is enabled. Disable after testing for better performance.`);
    Object.keys(require.cache).forEach(function(key) { delete require.cache[key] });
  };
*/
  console.log(`***trialMode is enabled. Disable after testing for better performance.`);
  Object.keys(require.cache).forEach(function(key) { delete require.cache[key] });

  //receivedMemo = memo;
  receivedOrder = JSON.parse(memo.body);

  var activateMinion = await global.loadModule(`system/minionServices/`, `activateMinion.js`);
  await activateMinion(memo.requestContext.connectionId, receivedOrder);
  
  //await global.sendMemo({returnOrder: returnOrder});
} 
catch (err) {
  
  console.log(err);

} finally {
  
  const response = {
    statusCode: 200,
    body: JSON.stringify('All Done.. from minionServices!'),
  };
    
  return response;
}};