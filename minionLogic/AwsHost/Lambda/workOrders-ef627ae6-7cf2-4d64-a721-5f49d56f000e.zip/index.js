console.log(`***Load workOrders`);

var fs         = require('fs');
var aws        = require('aws-sdk');
var s3Client   = new aws.S3({});
var apiGateway = new aws.ApiGatewayManagementApi({
    endpoint: 'https://85igzlcgab.execute-api.us-west-2.amazonaws.com/production/',
});

/////////////////////////////////////////
var postNotice = async function(notice, connection = global.services.bootService.event.requestContext.connectionId) {
///////////////////////////////////////  
console.log(`***postNotice to: '${connection}`);

	var params = {
		ConnectionId: connection,
		Data        : JSON.stringify(notice),
	};

	await apiGateway.postToConnection(params).promise();
	console.log('\n***Posted notice to: ', connection);
};

//////////////////////////////////////////////////////////
var loadModule = async function(directory, module) {
//////////////////////////////////////////////////////////

//load s3 file
    var params = {
        Bucket: 'minionlogic',
        Key: directory + module,
    };

    console.log(`getObject, params: `, params);
    var object = await s3Client.getObject(params).promise();
    var file = object.Body.toString('utf-8');

//create temp directory
    var tmpDir = '/tmp/'+ directory;
    console.log(`create dir: ${tmpDir}`);
    if(!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, {recursive: true});
    
//write object to temp directory
    var tmpPath= `${tmpDir}${module}`;
    fs.writeFileSync(tmpPath, file);
  
//load module
    console.log(`load file: ${tmpPath}`);
    delete require.cache[require.resolve(tmpPath)];
    return await require(tmpPath); 
};

//////////////////////////////////////////////
///////////////////  MAIN   //////////////////
//////////////////////////////////////////////
exports.handler = async (event) => {
console.log(`***Start workOrders`);

try {
//create shared services object
    global.services = {
        bootService: {
            event     : event,
            fs        : fs,
            s3Client  : s3Client,
            apiGateway: apiGateway,
            postNotice: postNotice,
            loadModule: loadModule,
        },
    };

//load required services
    global.services.systemService   = await global.services.bootService.loadModule('services/', 'systemService.js');
    global.services.contractService = await global.services.bootService.loadModule('services/', 'contractService.js');
    global.services.orderService    = await global.services.bootService.loadModule('services/', 'orderService.js');

//process workOrder
    var workOrder = JSON.parse(event.body);
    await global.services.orderService[workOrder.ORDER.action](workOrder);

} catch(err) {
//workOrder Failed
	
	var orderFailed = {
		ORDER : event.body,
		
		UPDATE: {
			timestamp: `${Date.now()}`,
			progress : 'FAILED',
			note     : '***ORDER ABORTED, with unexpected problem.\nerrMsg: ' + err.stack,
		},
	};

	console.log(`***Send orderFailed`);	
	await postNotice(orderFailed, event.requestContext.connectionId);
}

return  {
    statusCode: 200,
    body: JSON.stringify('workOrders: All Done!'),
}};
