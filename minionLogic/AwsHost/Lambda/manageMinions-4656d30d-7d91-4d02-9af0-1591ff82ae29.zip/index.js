var fs = require('fs')
var result = {
        statusCode: 200,
        body: JSON.stringify({
            $GUI: null,
            $COMPUTE: null,
            $STATUS: {
                code: 200,
                state: 'success',
                report: 'manageMinions completed',
            },
        })};
    
exports.handler = async (event) => {
try {

    console.log('**manageMInions**, connectionId: \n' + JSON.stringify(event.requestContext.connectionId, null, 2));
    //throw "thrown message";

    //process.env.NODE_PATH = '/mnt/microServices/microMinions' + ':' + process.env.NODE_PATH
    //require("module").Module._initPaths()
    require('activateMinion');
    require('webapp.learning.helloWorld');
    console.log('process.env.NODE_PATH: ' + process.env.NODE_PATH);

    //process.chdir('/mnt/microServices')
    //require('/mnt/microServices/manageMinions')
    
    console.log('s1');
    var dir = '/mnt/microServices';

    process.chdir( dir );
    
    //var exec = require('child_process').execSync;
    //console.log(exec('apt').toString());

    console.log('s2');
    var filenames = fs.readdirSync(dir);
  
    console.log("\nCurrent directory filenames in: " + dir + ', count: ' + filenames.length);
   
    filenames.forEach(file => {
        console.log(file);
    });
} catch (e) {
    console.log("entering catch block");
    console.log(e);
    console.log("leaving catch block");
    
    result.$STATUS.code = 200;
    result.$STATUS.state = 'fail';
    result.$STATUS.report = e;
} finally {
    console.log("entering and leaving the finally block");
    
    /*
    result = {
        statusCode: 200,
        body: JSON.stringify({
            report: 'Hello from manageMinions!',
        }),
    };
    */
    
    
    return result;
}};

