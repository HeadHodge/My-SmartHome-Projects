    console.log('**load manager**')
    
