console.log(`***Load workOrders`);

var fs         = require('fs');
var aws        = require('aws-sdk');
var s3Client   = new aws.S3({});
var apiGateway = new aws.ApiGatewayManagementApi({
    endpoint: 'https://85igzlcgab.execute-api.us-west-2.amazonaws.com/production/',
});

//////////////////////////////////////////////////////////
var loadModule = async function(directory, module) {
//////////////////////////////////////////////////////////

//load s3 file
    var params = {
        Bucket: 'minionlogic',
        Key: directory + module,
    };

    console.log(`getObject, params: `, params);
    var object = await s3Client.getObject(params).promise();
    var file = object.Body.toString('utf-8');

//create temp directory
    var tmpDir = '/tmp/'+ directory;
    console.log(`create dir: ${tmpDir}`);
    if(!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, {recursive: true});
    
//write object to temp directory
    var tmpPath= `${tmpDir}${module}`;
    fs.writeFileSync(tmpPath, file);
  
//load module
    console.log(`load file: ${tmpPath}`);
    delete require.cache[require.resolve(tmpPath)];
    return await require(tmpPath); 
};

//////////////////////////////////////////////
///////////////////  MAIN   //////////////////
//////////////////////////////////////////////
exports.handler = async (event) => {
console.log(`***Start workOrder`);
global.services = {
    bootService: {
        fs        : fs,
        s3Client  : s3Client,
        apiGateway: apiGateway,
        loadModule: loadModule,
    },
};

    global.services.systemService = await global.services.bootService.loadModule('services/', 'systemService.js');
    global.services.orderService = await global.services.bootService.loadModule('services/', 'orderService.js');
    console.log(`orderService: `, global.services.orderService);
    await global.services.orderService.createOrder(event);
    
    return  {
        statusCode: 200,
        body: JSON.stringify('workOrders: All Done!'),
    };
};
