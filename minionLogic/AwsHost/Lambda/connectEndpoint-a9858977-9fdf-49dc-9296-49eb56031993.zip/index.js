var aws = require('aws-sdk'); aws.config.update({region: 'us-west-2'});
var ses = new aws.SES({ region: "us-west-2" });
var s3 = new aws.S3({});

var connection;

//////////////////////////////////////////////////////////
async function sendMail(address, subject, content) {
//////////////////////////////////////////////////////////
const params = {
    Destination: {
        ToAddresses: [address],
    },
        
    Message: {
        Body: {
            Text: { Data: content },
        },

        Subject: { Data: subject },
    },
    
    Source: 'support@hodgemail.us',
};

// Send registration email
    console.log(`send new registration email to: `, address);
    await ses.sendEmail(params).promise();  
}

//////////////////////////////////////////////////////////
async function validateClient(connectOptions) {
//////////////////////////////////////////////////////////
console.log('Enter validateClient: ', connectOptions);
var objectKey, objectBuffer, client, params;

// verify credentials are provided
    if(!connectOptions.email || !connectOptions.name || !connectOptions.pin) throw "Invalid Credentials";
        
    client = {
        email: connectOptions.email,
        name : connectOptions.name,
        pin  : connectOptions.pin,
    };
    
// load client if registered
    try {
        objectKey = `clients/${connectOptions.email}`;
        console.log(`get objectKey: ${objectKey}`);
        
        objectBuffer=await s3.getObject({
            Bucket: 'minionlogic',
            Key: objectKey,
        }).promise();
        
        client = JSON.parse(objectBuffer.Body.toString());
        console.log(`***Client Found: `, client);
        
    } catch(err) {
//register new client if unregistered
        console.log(`***Client Not Found: `, client, err.message);
        
        params = {
            Bucket: 'minionlogic',
            Key   : 'clients/' + connectOptions.email,
            Body  : JSON.stringify(client),
            ContentType: 'text/plain',
        };
        
        await s3.putObject(params).promise();
        await sendMail(connectOptions.email, 'New minionLogic Client Registration Notice','Welcome to minionLogic!.');
        console.log(`***New Client Registered: `, client);
        
    }
    
// verify that registered client matches client provided
    if(client.name != connectOptions.name || client.pin != connectOptions.pin) throw "Credential Mismatch, retry or reset.";
}

///////////////////////////////////////////////
/////////////////  MAIN  //////////////////////
///////////////////////////////////////////////
exports.handler = async (event) => {
console.log('**connectEndpoint**, connectionId: \n' + JSON.stringify(event.requestContext.connectionId, null, 2));
var params = {}, connectOptions = event["queryStringParameters"];

try {
    connection = event.requestContext.connectionId;
   //console.log(event["queryStringParameters"]);

    await validateClient(connectOptions);

// save connection info
    console.log(`***Store connection: ${connection} with options: `, connectOptions);
        
    params = {
        Bucket: 'minionlogic',
        Key   : 'connections/' + connection,
        Body  : JSON.stringify(connectOptions),
        ContentType: 'text/plain',
    };
        
    await s3.putObject(params).promise();

}  catch (err) {
    console.log(`***ABORT: `, err);
    
    return {
        statusCode: 401,
        body: JSON.stringify('***CONNECTION ABORTED'),
    };
}

    console.log(`***CONNECTED: `);
    return {
        statusCode: 200,
        body: JSON.stringify('***CONNECTED'),
    };
};
