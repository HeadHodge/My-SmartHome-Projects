var aws = require('aws-sdk'); aws.config.update({region: 'us-west-2'});
var s3 = new aws.S3({});

///////////////////////////////////////////////
/////////////////  MAIN   /////////////////////
///////////////////////////////////////////////
exports.handler = async (event) => {
console.log('**disconnectEndpoint**, connectionId: \n' + JSON.stringify(event.requestContext.connectionId, null, 2));
console.log(`event data: `, event);
var connection = event.requestContext.connectionId;
var objectKey, objectBuffer, client, params;

    console.log(`get connection: ${connection}`);
    objectKey = `connections/${connection}`;

    objectBuffer=await s3.getObject({
        Bucket: 'minionlogic',
        Key: objectKey,
    }).promise();

    client = JSON.parse(objectBuffer.Body.toString('utf-8')).client;
    
    console.log(`remove connection: ${connection}`);
    
    params = {
        Bucket: 'minionlogic',
        Key: `connections/${connection}`,
    };
    
    await s3.deleteObject(params).promise();
    
    console.log(`remove connection by email: ${client}`);
    
    params = {
        Bucket: 'minionlogic',
        Key: `connections/${client}`,
    };
    
    await s3.deleteObject(params).promise();
    
    const response = {
        statusCode: 200,
        body: JSON.stringify('***DISCONNECTED'),
    };
    
    return response;
};
