var aws = require('aws-sdk'); aws.config.update({region: 'us-west-2'});
var s3 = new aws.S3({});

///////////////////////////////////////////////
/////////////////  MAIN   /////////////////////
///////////////////////////////////////////////
exports.handler = async (event) => {
console.log(`*** disconnectEndpoint**, connectionId: ${event.requestContext.connectionId}`);

try {
var connection = event.requestContext.connectionId;
var params;

// get connection
    params = {
        Bucket: 'minionlogic',
        Key   : `connections/${connection}.json`,
    };
    
    console.log(`load connectionInfo by connectionId, params: `, params);
    var object = await s3.getObject(params).promise();
    var connectionInfo = JSON.parse(object.Body.toString('utf-8'));

// delete connection    
    console.log(`remove connection by connectionId, params: `, params);
    await s3.deleteObject(params).promise();
/*
// get client
    params = {
        Bucket: 'minionlogic',
        Key   : `clients/${connectionInfo.client}.json`,
    };
    
    console.log(`load client, params: `, params);
    object = await s3.getObject(params).promise();
    var client = JSON.parse(object.Body.toString('utf-8'));

// set connection
    if(client.connection == connection) {
        client.connection = null;

        params = {
            Bucket     : 'minionlogic',
            Key        : `clients/${connectionInfo.client}.json`,
            Body       : JSON.stringify(client),
            ContentType: 'text/plain',
        };

        console.log(`update client, params: `, params);
        object = await s3.putObject(params).promise();
    }
*/

// done
    return {
        statusCode: 200,
        body: JSON.stringify('***DISCONNECTED'),
    };

} catch(err) {
    console.log(`*** ABORT DISCONNECT: `, err);

        return {
        statusCode: 401,
        body: JSON.stringify('***DISCONNECTED'),
    };
}};