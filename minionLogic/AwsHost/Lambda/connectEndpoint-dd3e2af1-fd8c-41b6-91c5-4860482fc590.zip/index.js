var aws = require('aws-sdk'); aws.config.update({region: 'us-west-2'});
var ses = new aws.SES({ region: "us-west-2" });
var s3 = new aws.S3({});

var connection;

//////////////////////////////////////////////////////////
async function sendMail(address, subject, content) {
//////////////////////////////////////////////////////////
const params = {
    Destination: {
        ToAddresses: [address],
    },
        
    Message: {
        Body: {
            Text: { Data: content },
        },

        Subject: { Data: subject },
    },
    
    Source: 'support@hodgemail.us',
  };

  await ses.sendEmail(params).promise();  
}

//////////////////////////////////////////////////////////
async function validateClient(connectOptions) {
//////////////////////////////////////////////////////////
console.log('Enter validateClient: ', connectOptions);
var objectKey, objectBuffer, client, params;

/*
    console.log(`***Store connection: ${connection} for client: ${connectOptions.email}`);
    console.log(`connections/${connection}:${connectOptions.email}/`);
    
    params = {
        Bucket: 'minionlogic',
        Key   : `connections/${connection}:${connectOptions.email}/`,
    };
        
    await s3.putObject(params).promise();
    
    
    objectKey = `connections/${connection}:`;
    console.log(`get objectKey: ${objectKey}`);
        
    objectBuffer=await s3.listObjectsV2({
        Bucket: 'minionlogic',
        Prefix: `connections/${connection}:`,
    }).promise();

    console.log(`objectBuffer: `, objectBuffer.Contents[0].Key);
*/

    //console.log(fs.readdirSync('/tmp'));
    //validate credential provided
    
    if(!connectOptions.email || !connectOptions.name || !connectOptions.pin) throw "Invalid Credentials";
        
    client = {
        email: connectOptions.email,
        name : connectOptions.name,
        pin  : connectOptions.pin,
    };
    
    //get registered client
    try {
        objectKey = `clients/${connectOptions.email}`;
        console.log(`get objectKey: ${objectKey}`);
        
        objectBuffer=await s3.getObject({
            Bucket: 'minionlogic',
            Key: objectKey,
        }).promise();
        
        client = JSON.parse(objectBuffer.Body.toString());
        console.log(`***Client Found: `, client);
        
    } catch(err) {
        console.log(`***Client Not Found: `, client, err);
        
        params = {
            Bucket: 'minionlogic',
            Key   : 'clients/' + connectOptions.email,
            Body  : JSON.stringify(client),
            ContentType: 'text/plain',
        };
        
        await s3.putObject(params).promise();
        sendMail(connectOptions.email, 'New minionLogic Client Registration Notice','Welcome to minionLogic!.');
        console.log(`***New Client Registered: `, client);
        
    }
    
    //found client
    if(client.name != connectOptions.name || client.pin != connectOptions.pin) throw "Credential Mismatch, retry or reset.";

    console.log(`***Store connection: ${connection} for client: ${connectOptions.email}`);
        
     params = {
        Bucket: 'minionlogic',
        Key   : 'connections/' + connection,
        Body  : JSON.stringify({client: connectOptions.email}),
        ContentType: 'text/plain',
    };
        
    await s3.putObject(params).promise();

    console.log(`***Store connection by email: ${connection} for client: ${connectOptions.email}`);
        
     params = {
        Bucket: 'minionlogic',
        Key   : 'connections/' + connectOptions.email,
        Body  : JSON.stringify({connecti: connection}),
        ContentType: 'text/plain',
    };
        
    await s3.putObject(params).promise();
}

///////////////////////////////////////////////
/////////////////  MAIN  //////////////////////
///////////////////////////////////////////////
exports.handler = async (event) => {
console.log('**connectEndpoint**, connectionId: \n' + JSON.stringify(event.requestContext.connectionId, null, 2));

try {
    connection = event.requestContext.connectionId;
   //console.log(event["queryStringParameters"]);
   //await sendMail();
   
    await validateClient(event["queryStringParameters"]);

}  catch (err) {
    console.log(`***ABORT: `, err);
    
    return {
        statusCode: 401,
        body: JSON.stringify('***CONNECTION ABORTED'),
    };
}

    console.log(`***CONNECTED: `);
    return {
        statusCode: 200,
        body: JSON.stringify('***CONNECTED'),
    };
};
