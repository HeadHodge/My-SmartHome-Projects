    console.log('Hello from localMinions.js');

// Load the SDK for JavaScript
var AWS = require('aws-sdk');
// Set the Region 
AWS.config.update({region: 'us-west-2'});
// Create S3 service object
var s3 = new AWS.S3({apiVersion: '2006-03-01'});
//var s3 = new AWS.S3();


module.exports = exports = async function(inMemo) {
   //console.log('arguments: %j\n', arguments);
   console.log('inMmemo', inMemo);


// Call S3 to list the buckets
// Call S3 to list the buckets
console.log('**List2 Buckets**');

var s3Objects=await s3.listBuckets({}).promise();  
console.log('**LIST2:**', s3Objects);
 




   
   var outMemo = {
		DEPARTMENT: 'jobOrders',
		
		ORDER: {
			action     : 'updateTask',
			submittedby: 'minionLogic',
			//confirmcode: inMemo.ORDER.confirmcode,
		},
		
	    STATUS: {
	        state  : 'DONE',
	        notes  : 'Minion: "example_minionLogic_helloWorld", Task: "displayMessage", completed successfully',
	    },
 
        RESULTS: {
		    SCRIPT: `alert('Hello Fellow Minion Lovers!'); `,
	    },
   };

   return outMemo;
};
