var fs = require("fs");

var AWS = require('aws-sdk'); AWS.config.update({region: 'us-west-2'});

var apiGateway = new AWS.ApiGatewayManagementApi({
    endpoint: 'https://8lcl01nzg5.execute-api.us-west-2.amazonaws.com/production/',
});

var S3 = new AWS.S3({
  
});

/////////////////////////////////////
async function postOrder(connection, workOrder) {
/////////////////////////////////////  
console.log(`***Enter postOrder`);

var params = {
    ConnectionId: connection,
    Data: JSON.stringify(workOrder),
  };

  console.log('\n**params**: ', params);
  await apiGateway.postToConnection(params).promise();
}

//////////////////////////////////////////////////////////
async function requireModule(modulePath, moduleFile) {
//////////////////////////////////////////////////////////
console.log(`***Enter requireModule: ${modulePath}, ${moduleFile}`);
var objectBuffer, objectKey = modulePath + moduleFile, tmpFile = '/tmp/'+ moduleFile;

  console.log(`get objectKey: ${objectKey}`);
  objectBuffer=await S3.getObject({Bucket: 'minionlogic', Key: objectKey}).promise();
  
  console.log(`create file: ${tmpFile}`);
  fs.writeFileSync(tmpFile, objectBuffer.Body.toString('utf-8'));
  
  console.log(`load file: ${tmpFile}`);
  return require(tmpFile); 
  //await postUpdate(receivedMemo.requestContext.connectionId, {dirData: dirData.toString('utf-8')});
}

///////////////////////////////////////////////
/////////////////  MAIN    ////////////////////
///////////////////////////////////////////////
exports.handler = async (receivedMemo) => {
console.log(`*** Start minionServices`);

var receivedOrder = JSON.parse(receivedMemo.body), returnOrder = {};

try {
  var activateMinion = require('./' + receivedOrder.TICKET.action); 
  returnOrder = await activateMinion(receivedOrder, requireModule);
  await postOrder(receivedMemo.requestContext.connectionId, {returnOrder: returnOrder});
} 
catch (err) {
    console.log(err);

} finally {
  
  const response = {
    statusCode: 200,
    body: JSON.stringify('All Done from minionServices!'),
  };
    
  return response;
}};