console.log(`***Load workOrders`);

var services = {};
services.system = require('./systemServices');
console.log(`name: `, services.system.name);

//////////////////////////////////////////////
/////////////  workOrders   //////////////////
//////////////////////////////////////////////
exports.handler = async (event) => {
console.log(`***Start workOrders`);
    
    var workOrder = await services.system.loadModule('system/', 'workOrders.js');
    await workOrder(event, services);
    
    return  {
        statusCode: 200,
        body: JSON.stringify('workOrders: All Done!'),
    };
};
