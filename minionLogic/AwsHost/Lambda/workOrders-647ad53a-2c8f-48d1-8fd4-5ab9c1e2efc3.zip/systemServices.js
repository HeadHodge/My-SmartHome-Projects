////////////////////////////////////////////////////////
////////////////// systemServices //////////////////////
////////////////////////////////////////////////////////
console.log('***Load systemServices');

var aws        = require('aws-sdk');
var s3Client   = new aws.S3({});
var fs         = require('fs');
var apiGateway = new aws.ApiGatewayManagementApi({
    endpoint: 'https://85igzlcgab.execute-api.us-west-2.amazonaws.com/production/',
});

/////////////////////////////////////////
var postNotice = async function(connection, notice) {
///////////////////////////////////////  
console.log(`***postNotice to: '${connection}`);

  var params = {
    ConnectionId: connection,
    Data        : JSON.stringify(notice),
  };

  await apiGateway.postToConnection(params).promise();
  console.log('\n***Posted Connection to: ', connection);
};

/////////////////////////////////////////////////////////
var loadObject = async function(objectKey) {
//////////////////////////////////////////////////////////
console.log(`***loadObject: ${objectKey}`);
var objectBuffer;

//getObject
    var params = {
        Bucket: 'minionlogic',
        Key   : objectKey,
    };
  
  console.log(`getObject, params: : `, params);
  var object = await s3Client.getObject(params).promise();
  console.log(`objectBuffer: `, object.Body.toString('utf-8'));
  return JSON.parse(objectBuffer.Body.toString('utf-8')); 
};

//////////////////////////////////////////////////////////
var loadModule = async function(directory, module) {
//////////////////////////////////////////////////////////

//var objectBuffer, objectKey = path + module, tmpDir = '/tmp/'+ path, tmpFile = '/tmp/'+ path + module;

    var params = {
        Bucket: 'minionlogic',
        Key: directory + module,
    };

    console.log(`getObject, params: `, params);
    var object = await s3Client.getObject(params).promise();
    var file = object.Body.toString('utf-8');
    //console.log(`file: `, file);

//create temp directory
    var tmpDir = '/tmp/'+ directory;
    console.log(`create dir: ${tmpDir}`);
    if(!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, {recursive: true});
    
//write object to temp directory
    var tmpPath= `${tmpDir}${module}`;
    fs.writeFileSync(tmpPath, file);
  
  console.log(`load file: ${tmpPath}`);
  return require(tmpPath); 
};

  //////////////////////////////////////////////
  ////////NOTE: REMOVE REMOVE REQIRE CACHE//////
  ///////////////WHEN NOT TESTING///////////////
  //////////////////////////////////////////////
/*
  if(memo["queryStringParameters"].trialMode == 'on') {
    console.log(`***trialMode is enabled. Disable after testing for better performance.`);
    Object.keys(require.cache).forEach(function(key) { delete require.cache[key] });
  };
*/
  console.log(`***trialMode is enabled. Disable after testing for better performance.`);
  Object.keys(require.cache).forEach(function(key) { delete require.cache[key] });

//////////////////////////////////////////////////////////
module.exports = {
//////////////////////////////////////////////////////////
    name      : 'systemServices',
    aws       : aws,
    fs        : fs,
    s3Client  : s3Client,
    apiGateway: apiGateway,
    postNotice : postNotice,
    loadObject: loadObject,
    loadModule: loadModule,
};