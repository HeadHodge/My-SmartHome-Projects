var fs = require("fs");

var AWS = require('aws-sdk'); AWS.config.update({region: 'us-west-2'});

var apiGateway = new AWS.ApiGatewayManagementApi({
    endpoint: 'https://8lcl01nzg5.execute-api.us-west-2.amazonaws.com/production/',
});

var S3 = new AWS.S3({
  
});

var receivedMemo = {}, receivedOrder = {};

/////////////////////////////////////////
global.sendMemo = async function(content, connection = receivedMemo.requestContext.connectionId) {
//////////////////////////////////////  
console.log(`***Enter sendMemo`);

var params = {
    ConnectionId: connection,
    Data: JSON.stringify(content),
  };

  //console.log('\n**params**: ', params);
  await apiGateway.postToConnection(params).promise();
};

//////////////////////////////////////////////////////////
async function loadRoutine(modulePath, moduleFile) {
//////////////////////////////////////////////////////////
console.log(`***Enter requireModule: ${modulePath}, ${moduleFile}`);
var objectBuffer, objectKey = modulePath + moduleFile, tmpDir = '/tmp/'+ modulePath, tmpFile = '/tmp/'+ modulePath + moduleFile;
  
  console.log(`get objectKey: ${objectKey}`);
  objectBuffer=await S3.getObject({Bucket: 'minionlogic', Key: objectKey}).promise();

  console.log(`create dir: ${tmpDir}`);
  if (!fs.existsSync(tmpDir)){
    fs.mkdirSync(tmpDir, { recursive: true });
  }
  
  console.log(`create file: ${tmpFile}`);
  fs.writeFileSync(tmpFile, objectBuffer.Body.toString('utf-8'));
  
  console.log(`load file: ${tmpFile}`);
  return require(tmpFile); 
  //await postUpdate(receivedMemo.requestContext.connectionId, {dirData: dirData.toString('utf-8')});
}

///////////////////////////////////////////////
/////////////////  MAIN    ////////////////////
///////////////////////////////////////////////
exports.handler = async (memo) => {
console.log(`*** Start minionServices`);
var returnOrder = {};

try {
  //////////////////////////////////////////////
  ////////NOTE: REMOVE REMOVE REQIRE CACHE//////
  ///////////////WHEN NOT TESTING///////////////
  //////////////////////////////////////////////
  Object.keys(require.cache).forEach(function(key) { delete require.cache[key] });

  receivedMemo = memo;
  receivedOrder = JSON.parse(memo.body);

  //console.log(fs.readdirSync('/tmp'));
  //var activateMinion = require('./' + receivedOrder.TICKET.action);
  var activateMinion = await loadRoutine(`system/minionServices/activateMinion/`, `activateMinion.js`);

  returnOrder = await activateMinion(receivedOrder, loadRoutine);
  await global.sendMemo({returnOrder: returnOrder});
} 
catch (err) {
  
  console.log(err);

} finally {
  
  const response = {
    statusCode: 200,
    body: JSON.stringify('All Done.. from minionServices!'),
  };
    
  return response;
}};