    console.log('Hello from helloWorld:');

    console.log('Hello arguments: ' + arguments['0']);

module.exports = exports = function(inMemo) {
   //console.log('arguments: %j\n', arguments);
   console.log('inMmemo', inMemo);
   
   var outMemo = {
		DEPARTMENT: 'jobOrders',
		
		ORDER: {
			action     : 'updateTask',
			submittedby: 'minionLogic',
			confirmcode: 'job210.step27',
		},
		
	    STATUS: {
	        state  : 'DONE',
	        notes  : 'Minion task completed successfully',
	    },
 
        RESULTS: {
		    SCRIPT: `alert('Hello Fellow Minion Lovers!'); `,
	    },
   };

   return outMemo;
};
