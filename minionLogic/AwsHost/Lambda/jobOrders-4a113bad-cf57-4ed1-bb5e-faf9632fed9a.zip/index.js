
exports.handler = async (event) => {
var jobMemo = JSON.parse(event.body);

let payload = {
    statusCode: 200,
    body : {},
};


try {
    var app = ' hi';
    var resultMemo = require('./' + jobMemo.DATA.registry + '/' + jobMemo.DATA.minionName + '/script.js')(jobMemo); 
    console.log("resultMemo: ", resultMemo);
} 
catch (err) {
    console.log(err);

    var resultMemo = {
	    DEPARTMENT: 'jobOrders',
		
		ORDER: {
			action     : 'updateTask',
			submittedby: 'minionLogic',
			confirmcode: 'job210.step27',
		},
		
	    STATUS: {
	        state  : 'REJECTED',
	        notes  : err.message,
	    },
 
		SCRIPT: `
		    alert('Hello Fellow Minion Lovers!'); 
		`,
	};

} finally {
    payload.body = JSON.stringify(resultMemo);
    return payload;
}};