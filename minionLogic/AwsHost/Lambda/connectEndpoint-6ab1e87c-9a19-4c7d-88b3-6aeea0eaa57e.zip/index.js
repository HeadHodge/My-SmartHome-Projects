var aws = require("aws-sdk");
var ses = new aws.SES({ region: "us-west-2" });

async function mail() {
    const params = {
        Destination: {
            ToAddresses: ['bob@hodgemail.us'],
        },
        
        Message: {
            Body: {
                Text: { Data: 'Test' },
            },

        Subject: { Data: 'Test Email' },
    },
    
    Source: 'support@hodgemail.us',
  };

  await ses.sendEmail(params).promise();  
};

exports.handler = async (event) => {
    console.log('**connectEndpoint**, connectionId: \n' + JSON.stringify(event.requestContext.connectionId, null, 2))

    await mail();

    // TODO implement
    var response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    
    return response;
};

