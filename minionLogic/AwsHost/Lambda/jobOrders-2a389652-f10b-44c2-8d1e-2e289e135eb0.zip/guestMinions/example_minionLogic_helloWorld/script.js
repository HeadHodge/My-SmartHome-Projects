    console.log('Hello from helloWorld:');

    console.log('Hello arguments: ' + arguments['0']);

module.exports = exports = function(inMemo) {
   //console.log('arguments: %j\n', arguments);
   console.log('inMmemo', inMemo);
   
   var outMemo = {
		DEPARTMENT: 'jobOrders',
		
		ORDER: {
			action     : 'updateTask',
			submittedby: 'minionLogic',
			confirmcode: inMemo.ORDER.confirmcode,
		},
		
	    STATUS: {
	        state  : 'DONE',
	        notes  : 'Minion: "example_minionLogic_helloWorld", Task: "displayMessage", completed successfully',
	    },
 
        RESULTS: {
		    SCRIPT: `alert('Hello Fellow Minion Lovers!'); `,
	    },
   };

   return outMemo;
};
