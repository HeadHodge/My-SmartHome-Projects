
exports.handler = async (inPayload) => {
try {
    var inMemo = JSON.parse(inPayload.body);

    var payload = {
        statusCode: 200,
        body : {},
    };

    var resultMemo = require('./' + inMemo.DATA.registry + '/' + inMemo.DATA.minionName + '/script.js')(inMemo); 
    console.log("resultMemo: ", resultMemo);
} 
catch (err) {
    console.log(err);

    var resultMemo = {
	    DEPARTMENT: 'jobOrders',
		
		ORDER: {
			action     : 'updateTask',
			submittedby: 'minionLogic',
			confirmcode: inMemo.ORDER.confirmcod,
		},
		
	    STATUS: {
	        state  : 'ABORTED',
	        notes  : err.message,
	    },
 
		SCRIPT: `
		    alert('Hello Fellow Minion Lovers!'); 
		`,
	};

} finally {
    payload.body = JSON.stringify(resultMemo);
    return payload;
}};