var AWS = require('aws-sdk');

var awsGateway = new AWS.ApiGatewayManagementApi({
    apiVersion: '2018-11-29',
    endpoint: 'https://5dl6cjqlqa.execute-api.us-west-2.amazonaws.com/test',
    region: 'us-west-2'
});


exports.handler = async (inPayload) => {
try {
    var inMemo = JSON.parse(inPayload.body);

    var payload = {
        statusCode: 200,
        body : {},
    };
    
    console.log('connectionId:' + inPayload.requestContext.connectionId);
    await awsGateway.postToConnection({
       ConnectionId: inPayload.requestContext.connectionId,
       Data: JSON.stringify({name: 'boobboobvboobboob'}),
    }).promise();


    var resultMemo = require('./' + inMemo.DATA.registry + '/' + inMemo.DATA.minionName + '/script.js')(inMemo); 
    console.log("resultMemo: ", resultMemo);
} 
catch (err) {
    console.log(err);

    var resultMemo = {
	    DEPARTMENT: 'jobOrders',
		
		ORDER: {
			action     : 'updateTask',
			submittedby: 'minionLogic',
			confirmcode: inMemo.ORDER.confirmcod,
		},
		
	    STATUS: {
	        state  : 'ABORTED',
	        notes  : err.message,
	    },
 
		SCRIPT: `
		    alert('Hello Fellow Minion Lovers!'); 
		`,
	};

} finally {
    payload.body = JSON.stringify(resultMemo);
    return payload;
}};