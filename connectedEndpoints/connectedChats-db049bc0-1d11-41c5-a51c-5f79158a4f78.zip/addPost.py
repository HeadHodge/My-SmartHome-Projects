import json, boto3
import imports.alertEndpoints as alertEndpoints
print('Loading addPost')

def start(client, payload, event, context):
        print(f'Start addPost')

        client.put_object(
            Bucket='www.connectedchats.com',
            Key='entities/categories/'+payload['category']+'.category',
            Body=json.dumps({'category': payload['category'], 'uts': payload['uts']}),
        )
     
        client.put_object(
            Bucket='www.connectedchats.com',
            Key='entities/posts/'+payload['uts']+'.post',
            Body=json.dumps(payload),
        )
    
        client.put_object(
            Bucket='www.connectedchats.com',
            Key='indexes/categories/'+payload['category']+'/posts/'+payload['uts']+'/',
        )
    
        alertEndpoints.start(client, payload, event, context)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'state' : 1,
                'lambda': 'addTopi',
                'status': 'New topic added',
            }),
        }
