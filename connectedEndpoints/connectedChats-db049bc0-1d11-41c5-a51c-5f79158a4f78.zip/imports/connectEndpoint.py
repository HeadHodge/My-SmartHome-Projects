print('Load connectEndpoint')

def start(client, connectionId, event, context):
    print(f'Start connectEndpoint')
    
    client.put_object(
        Bucket='www.connectedchats.com',
        Key='indexes/connections/'+connectionId+'/',
    )

    print(f'connectEndpoint completed')

    return {
        'statusCode': 200,
        'body': json.dumps({
            'state' : 1,
            'lambda': f'connectEndpoint',
            'status': f'endpoint connected',
        }),
    }
