print('Load disconnectEndpoint')

def start(client, connectionId, event, context):
    print(f'Start disconnectEndpoint')
    
    client.delete_object(
        Bucket='www.connectedchats.com',
        Key='indexes/connections/'+connectionId+'/',
    )
        
    print(f'disconnectEndpoint completed')

    return {
        'statusCode': 200,
        'body': json.dumps({
            'state' : 1,
            'lambda': f'disconnectEndpoint',
            'status': f'endpoint disconnected',
        }),
    }
