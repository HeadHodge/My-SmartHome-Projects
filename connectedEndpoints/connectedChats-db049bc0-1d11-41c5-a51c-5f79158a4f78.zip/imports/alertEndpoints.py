import json, traceback, boto3

print('Loading alertEndpoints')

def start(client, payload, event, context):
    print(f'Start alertEndpoints')

    list = client.list_objects_v2(
        Bucket='www.connectedchats.com',
        Prefix='indexes/categories/random thoughts/posts/211124.0135.245/'
    )
    
    path = list['Contents'][0]['Key'].split('/')
    key = 'entities/posts/'+path[len(path)-2]+'.post'
   
    print(path, key)

    response = client.get_object(
        Bucket='www.connectedchats.com',
        Key=key,
    )

    body = json.loads(response['Body'].read())
    print(f'uts: {body["uts"]},  post: {body["post"]}')
    
    prefix = 'indexes/connections/'
    
    list = client.list_objects_v2(
        Bucket='www.connectedchats.com',
        Prefix=prefix,
    )
    
    path = list['Contents'][0]['Key'].split('/')
    connectionId = path[len(path)-2]
    print(f'connectionId: {connectionId}')
    
    endpoint = 'https://jzqy8hjd1g.execute-api.us-west-1.amazonaws.com/development'
    gatewayapi = boto3.client("apigatewaymanagementapi", endpoint_url=endpoint)
    gatewayapi.post_to_connection(ConnectionId=connectionId, Data=body["post"])
    
    print(f'alertEndpoints completed')
